// 
// Copyright (C) 2016, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows.Media;
using System.Xml.Serialization;
#endregion

// Add this to your declarations to use StreamWriter
using System.IO;

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.Avi
{
	public class DataWriter : Indicator
	{
		private string path;
		private StreamWriter sw; // a variable for the StreamWriter that will be used 
		
		protected override void OnStateChange()
		{
			if(State == State.SetDefaults)
			{
				Calculate 		= Calculate.OnBarClose;
				Name			= "Data Writer";
				filename 		= "es15.txt";
				//path 			= NinjaTrader.Core.Globals.UserDataDir + "MyTestFile.txt"; // Define the Path to our test file
			}
			else if (State == State.Configure)
			{
				path 										= NinjaTrader.Core.Globals.UserDataDir + filename;
			}
			// Necessary to call in order to clean up resources used by the StreamWriter object
			else if(State == State.Terminated)
			{
				if (sw != null)
				{
					sw.Close();
					sw.Dispose();
					sw = null;
				}
			}
		}

		protected override void OnBarUpdate()
		{
			sw = File.AppendText(path);  // Open the path for writing
			sw.WriteLine(Time[0] + "," + Open[0] + "," + High[0] + "," + Low[0] + "," + Close[0]); // Append a new line to the file
			sw.Close(); // Close the file to allow future calls to access the file again.
		}
		
		#region Properties
		[NinjaScriptProperty]
		[Display(Name="File Name", Order=1, GroupName="Parameters")]
		public string filename
		{ get; set; }
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private Avi.DataWriter[] cacheDataWriter;
		public Avi.DataWriter DataWriter(string filename)
		{
			return DataWriter(Input, filename);
		}

		public Avi.DataWriter DataWriter(ISeries<double> input, string filename)
		{
			if (cacheDataWriter != null)
				for (int idx = 0; idx < cacheDataWriter.Length; idx++)
					if (cacheDataWriter[idx] != null && cacheDataWriter[idx].filename == filename && cacheDataWriter[idx].EqualsInput(input))
						return cacheDataWriter[idx];
			return CacheIndicator<Avi.DataWriter>(new Avi.DataWriter(){ filename = filename }, input, ref cacheDataWriter);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.Avi.DataWriter DataWriter(string filename)
		{
			return indicator.DataWriter(Input, filename);
		}

		public Indicators.Avi.DataWriter DataWriter(ISeries<double> input , string filename)
		{
			return indicator.DataWriter(input, filename);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.Avi.DataWriter DataWriter(string filename)
		{
			return indicator.DataWriter(Input, filename);
		}

		public Indicators.Avi.DataWriter DataWriter(ISeries<double> input , string filename)
		{
			return indicator.DataWriter(input, filename);
		}
	}
}

#endregion

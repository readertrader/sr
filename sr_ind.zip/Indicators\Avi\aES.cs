#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using System.IO;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.Avi
{
	public class aES : Indicator
	{
        #region Variables

		// This sets the path in which the text file will be created.
		private string path;
		private DateTime parsedDate;
		private DateTime endDate;
		// Creates a StreamReader object
		private StreamReader sr;
		private int counts;
        #endregion
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "aES";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				AllowRemovalOfDrawObjects = true;
				filename 									= "es.txt";
				path 										= NinjaTrader.Core.Globals.UserDataDir + filename;
				DisplayInDataBox							= false;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= false;
				DrawVerticalGridLines						= false;
				PaintPriceMarkers							= false;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				Zone_size_half					= 0.5;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar == 0)
			{
			// Checks to see if the file exists
				if (!File.Exists(path))
				{
					// If file does not exist, let the user know
					Print("File does not exist.");
					return;
				}
	
				try
				{
					string[] readText = File.ReadAllLines(path);
        			foreach (string s in readText)
			        {
			            if (s.Contains('/'))
						{

							parsedDate = DateTime.Parse(s);
							endDate = parsedDate.AddHours(16);

						}
						
						else if (s != null)
						{
							double value = double.Parse(s);
							Draw.Rectangle(this, s+counts.ToString(), parsedDate, value + Zone_size_half, endDate, value - Zone_size_half, Brushes.Blue);
							counts++;
						}
			        }
					//Draw.RegionHighlightY(this, line, value + Zone_size_half, value-Zone_size_half, Brushes.Black);
					
				}
				catch (Exception e)
				{
					// Outputs the error to the log
					Log("You cannot write and read from the same file at the same time. Please remove SampleStreamWriter.", NinjaTrader.Cbi.LogLevel.Error);
					Print(e.ToString());
				}
			//Add your custom indicator logic here.
			}
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Zone_size_half", Order=2, GroupName="Parameters")]
		public double Zone_size_half
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="File Name", Order=1, GroupName="Parameters")]
		public string filename
		{ get; set; }
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private Avi.aES[] cacheaES;
		public Avi.aES aES(double zone_size_half, string filename)
		{
			return aES(Input, zone_size_half, filename);
		}

		public Avi.aES aES(ISeries<double> input, double zone_size_half, string filename)
		{
			if (cacheaES != null)
				for (int idx = 0; idx < cacheaES.Length; idx++)
					if (cacheaES[idx] != null && cacheaES[idx].Zone_size_half == zone_size_half && cacheaES[idx].filename == filename && cacheaES[idx].EqualsInput(input))
						return cacheaES[idx];
			return CacheIndicator<Avi.aES>(new Avi.aES(){ Zone_size_half = zone_size_half, filename = filename }, input, ref cacheaES);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.Avi.aES aES(double zone_size_half, string filename)
		{
			return indicator.aES(Input, zone_size_half, filename);
		}

		public Indicators.Avi.aES aES(ISeries<double> input , double zone_size_half, string filename)
		{
			return indicator.aES(input, zone_size_half, filename);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.Avi.aES aES(double zone_size_half, string filename)
		{
			return indicator.aES(Input, zone_size_half, filename);
		}

		public Indicators.Avi.aES aES(ISeries<double> input , double zone_size_half, string filename)
		{
			return indicator.aES(input, zone_size_half, filename);
		}
	}
}

#endregion

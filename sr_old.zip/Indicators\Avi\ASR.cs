#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.Avi
{
	public class ASR : Indicator
	{
		private double[,] Supports = new double [10000,4];
		private double[,] Resistances = new double [10000,4];
		/*
		0:	State (0 = neutral, 1 = active, 2 = touched, 3 = broken, 4 = touched other way, 5 = broken other way) 
		1:	Level
		2:	Barnumber
		3:	Pre-touches
		4:	MFE
		*/
		private int s_count;
		private int r_count;
		private int state;
		private bool existingsupport = false;
		private bool existingresistance = false;

	
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				AllowRemovalOfDrawObjects = true;
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "ASR";
				Calculate									= Calculate.OnBarClose;
				leftstrength								= 10;
				rightstrength								= 10;
				minutes										= 15;
				hours_to_keep 								= 60;
				state 										= 0;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
				AddDataSeries(BarsPeriodType.Minute, minutes);
				
			}
		}

		protected override void OnBarUpdate()
			
		{	
			if (minutes > 1){
				state = 1;
			}
			if (BarsInProgress == state){ 
			if (CurrentBar < leftstrength + rightstrength +1)
			return;
			
			#region Supports
			
			existingsupport = false;
			for (int i = 0; i < 10000; i++)
			{
				if (Low[rightstrength] == Supports[i,1] && Supports[i,0] == 1)
				{existingsupport = true;}
			}
			if (Low[rightstrength] == MIN(Low,(leftstrength+rightstrength + 1 ))[0] && existingsupport == false)
			{
				Supports[s_count,0] = 1;
				Supports[s_count,1] = Low[rightstrength];
				Supports[s_count,3] = Close[rightstrength];
				Supports[s_count,2] = CurrentBar-rightstrength;
				DateTime newTime = Time[rightstrength];
				newTime.AddHours(hours_to_keep);
				
				
				Draw.Rectangle(this, "support" + s_count.ToString(),rightstrength, Supports[s_count,1],-1000,Supports[s_count,3], Brushes.DodgerBlue);	
				 //Draw.Ray(this, "support" + s_count.ToString(),0, Supports[s_count,1],-1,Supports[s_count,1], Brushes.DodgerBlue);	
				s_count ++;
			}
			
//			for (int i = 0; i < 10000; i++)
//			{
//				if (Supports[i,0] == 1)
//				{
//					if (Close[0] < Supports[i,1])
//					{
//						Supports [i,0] = 2;
//						RemoveDrawObject("support" + i.ToString());
//						Draw.Rectangle(this, "supports" + i.ToString(),CurrentBar - (int)Supports[i,2] - rightstrength, Supports[i,1],0,Supports[i,3], Brushes.DodgerBlue);		
//						//Draw.Line(this, "supports" + i.ToString(),CurrentBar - (int)Supports[i,2] - rightstrength, Supports[i,1],0,Supports[i,1], Brushes.DodgerBlue);		
//					}
//				}
//			}
			
			#endregion
			#region Resistances
			
			existingresistance = false;
			for (int i = 0; i < 10000; i++)
			{
				if (High[rightstrength] == Resistances[i,1] && Resistances[i,0] == 1)
				{existingresistance = true;}
			}
			if (High[rightstrength] == MAX(High,(leftstrength+rightstrength + 1))[0] && existingresistance == false)
			{
				//Draw.ArrowDown(this, CurrentBar.ToString(),true,0,High[0]+100, Brushes.Red);
				Resistances[r_count,0] = 1;
				Resistances[r_count,1] = High[rightstrength];
				Resistances[r_count,2] = CurrentBar-rightstrength;
				
				//Draw.Text(this,"resistance index" +CurrentBar, r_count.ToString(), rightstrength, High[rightstrength] + 1*TickSize, Brushes.White);
				Draw.Line(this, "resistance inactive" + r_count.ToString(),false,rightstrength, Resistances[r_count,1],0,Resistances[r_count,1], Brushes.Pink,DashStyleHelper.Dash,1);	
				Draw.Ray(this, "resistance" + r_count.ToString(),0,Resistances[r_count,1],-1,Resistances[r_count,1], Brushes.Fuchsia);	
				r_count ++;
			}
			
			for (int j = 0; j < 10000; j++)
			{

				if (Resistances[j,0] == 1)
				{
					if (Close[0] > Resistances[j,1])
					{
						Resistances[j,0] = 2;
						RemoveDrawObject("resistance" + j.ToString());
						Draw.Line(this, "resistances" + j.ToString(),CurrentBar - (int)Resistances[j,2]- rightstrength, Resistances[j,1],0,Resistances[j,1], Brushes.Fuchsia);		
					}
				}
			}
			#endregion
		}
		}
		#region Properties
		
		[NinjaScriptProperty]
		[Range(1, 1000)]
		[Display(Name="Left Strength", Order=1, GroupName="Parameters")]
		public int leftstrength
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(1, 1000)]
		[Display(Name="Right Strength", Order=2, GroupName="Parameters")]
		public int rightstrength
		{ get; set; }
		
		[Range(1, 240)]
		[NinjaScriptProperty]
		[Display(Name="Minutes", Order=3, GroupName="Parameters")]
		public int minutes
		{ get; set; }

		[Range(0, 1000)]
		[NinjaScriptProperty]
		[Display(Name="Hours To Keep", Order=4, GroupName="Parameters")]
		public double hours_to_keep
		{ get; set; }
		
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private Avi.ASR[] cacheASR;
		public Avi.ASR ASR(int leftstrength, int rightstrength, int minutes, double hours_to_keep)
		{
			return ASR(Input, leftstrength, rightstrength, minutes, hours_to_keep);
		}

		public Avi.ASR ASR(ISeries<double> input, int leftstrength, int rightstrength, int minutes, double hours_to_keep)
		{
			if (cacheASR != null)
				for (int idx = 0; idx < cacheASR.Length; idx++)
					if (cacheASR[idx] != null && cacheASR[idx].leftstrength == leftstrength && cacheASR[idx].rightstrength == rightstrength && cacheASR[idx].minutes == minutes && cacheASR[idx].hours_to_keep == hours_to_keep && cacheASR[idx].EqualsInput(input))
						return cacheASR[idx];
			return CacheIndicator<Avi.ASR>(new Avi.ASR(){ leftstrength = leftstrength, rightstrength = rightstrength, minutes = minutes, hours_to_keep = hours_to_keep }, input, ref cacheASR);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.Avi.ASR ASR(int leftstrength, int rightstrength, int minutes, double hours_to_keep)
		{
			return indicator.ASR(Input, leftstrength, rightstrength, minutes, hours_to_keep);
		}

		public Indicators.Avi.ASR ASR(ISeries<double> input , int leftstrength, int rightstrength, int minutes, double hours_to_keep)
		{
			return indicator.ASR(input, leftstrength, rightstrength, minutes, hours_to_keep);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.Avi.ASR ASR(int leftstrength, int rightstrength, int minutes, double hours_to_keep)
		{
			return indicator.ASR(Input, leftstrength, rightstrength, minutes, hours_to_keep);
		}

		public Indicators.Avi.ASR ASR(ISeries<double> input , int leftstrength, int rightstrength, int minutes, double hours_to_keep)
		{
			return indicator.ASR(input, leftstrength, rightstrength, minutes, hours_to_keep);
		}
	}
}

#endregion

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using System.IO;
#endregion


//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class AviSR : Indicator
	{
        #region Variables

		// This sets the path in which the text file will be created.
		private string path;
		
		// Creates a StreamReader object
		private StreamReader sr;
        #endregion
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "AviSR";
				path 										= NinjaTrader.Core.Globals.UserDataDir + "sr.txt";
				IsOverlay									= false;

				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
			}

		}

		protected override void OnBarUpdate()
		{
			// Checks to see if the file exists
			if (!File.Exists(path))
			{
				// If file does not exist, let the user know
				Print("File does not exist.");
				return;
			}
			
			/* The try-catch block is used for error handling.
			In this case it is used to ensure you only have one stream object operating on the same file at any given moment. */
			try
			{
				// Sets the file the StreamReader will read from
				sr = new System.IO.StreamReader(path);

				string line;
				
				// Read lines and calculate the current day's OHLC from the file. While loop will go through the whole file.
				while ((line = sr.ReadLine()) != null) 
				{
					double value = double.Parse(line);
					
					Draw.HorizontalLine(this, line, value, Brushes.Blue, DashStyleHelper.Dot, 2);
					// Splits the line at every white space. Places each split into the string array
					// string[] split = line.Split(new char[] {','});

				}
			}
			catch (Exception e)
			{
				// Outputs the error to the log
				Log("You cannot write and read from the same file at the same time. Please remove SampleStreamWriter.", NinjaTrader.Cbi.LogLevel.Error);
				Print(e.ToString());
			}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AviSR[] cacheAviSR;
		public AviSR AviSR()
		{
			return AviSR(Input);
		}

		public AviSR AviSR(ISeries<double> input)
		{
			if (cacheAviSR != null)
				for (int idx = 0; idx < cacheAviSR.Length; idx++)
					if (cacheAviSR[idx] != null &&  cacheAviSR[idx].EqualsInput(input))
						return cacheAviSR[idx];
			return CacheIndicator<AviSR>(new AviSR(), input, ref cacheAviSR);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AviSR AviSR()
		{
			return indicator.AviSR(Input);
		}

		public Indicators.AviSR AviSR(ISeries<double> input )
		{
			return indicator.AviSR(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AviSR AviSR()
		{
			return indicator.AviSR(Input);
		}

		public Indicators.AviSR AviSR(ISeries<double> input )
		{
			return indicator.AviSR(input);
		}
	}
}

#endregion
